2022 Kaggle NBME 金牌方案 训练部分代码，by wagege，解析见

推理部分见 https://www.kaggle.com/code/syzong/fork-of-893-fast-test-02e8e7/notebook?scriptVersionId=94415842
